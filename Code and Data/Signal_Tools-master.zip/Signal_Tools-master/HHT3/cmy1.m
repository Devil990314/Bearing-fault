filename = 'cmy.wav';
[y,Fs]=audioread(filename);